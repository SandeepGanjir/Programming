package com.oracle.multitenent.ratecontrol.model;

import javax.xml.bind.annotation.XmlRootElement;
import java.sql.Timestamp;

/**
 * This is a model to describe Rate Control Statistics
 */
@XmlRootElement
public class Stat {
    private final String partition;
    private final String rate_key;
    private final String client_id;
    private int allowed;
    private int blocked;
    private Timestamp time;

    public Stat(String partition, String rate_key, String client_id) {
        this.partition = partition;
        this.rate_key = rate_key;
        this.client_id = client_id;
        this.allowed = 0;
        this.blocked = 0;
        this.time = new Timestamp(0);
    }

    public int incrementAllowed() {
        return ++allowed;
    }

    public int incrementBlocked() {
        return ++blocked;
    }

    public String getPartition() {
        return partition;
    }

    public String getRate_key() {
        return rate_key;
    }

    public String getClient_id() {
        return client_id;
    }

    public int getAllowed() {
        return allowed;
    }

    public int getBlocked() {
        return blocked;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setAllowed(int allowed) {
        this.allowed = allowed;
    }

    public void setBlocked(int blocked) {
        this.blocked = blocked;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }
}

package com.oracle.multitenent.ratecontrol.server;

import com.oracle.multitenent.ratecontrol.model.Rule;
import com.oracle.multitenent.ratecontrol.model.Stat;
import com.oracle.multitenent.ratecontrol.util.DbUtil;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.sql.Timestamp;
import java.util.Hashtable;

/**
 * For batch statistics collection
 * Define MinPublishInterval in config file
 */
class BatchedStatistics {
    private static final Logger LOGGER = LoggerFactory.getLogger(BatchedStatistics.class);
    private static final Hashtable<String, Hashtable<String, Stat>> statsManager = new Hashtable<>();
    private static final String ClientId = "rcserver";
    private static int MinPublishInterval = 300000;

    private BatchedStatistics() {}

    static void processedRequest(Rule rule, boolean isAllowed) {
        Stat stat = statsManager.computeIfAbsent(rule.getPartition(), p -> new Hashtable<>())
                .computeIfAbsent(rule.getName(), name -> new Stat(rule.getPartition(), rule.getName(), ClientId));

        synchronized (stat) {
            if (isAllowed)
                stat.incrementAllowed();
            else
                stat.incrementBlocked();

            long lastPublishedTime = stat.getTime().getTime();
            long currentTime = System.currentTimeMillis();
            if (lastPublishedTime + MinPublishInterval < currentTime) {
                stat.setTime(new Timestamp(currentTime));
                DbUtil.publishStatistics(stat);
                stat.setAllowed(0);
                stat.setBlocked(0);
            }
        }
    }

    static void setMinPublishInterval(int minPublishInterval) {
        MinPublishInterval = minPublishInterval;
    }
}

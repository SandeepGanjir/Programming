package com.oracle.multitenent.ratecontrol.server;

import com.oracle.multitenent.ratecontrol.common.RuleTree;
import com.oracle.multitenent.ratecontrol.model.Grant;
import com.oracle.multitenent.ratecontrol.model.Request;
import com.oracle.multitenent.ratecontrol.model.RequestGrant;
import com.oracle.multitenent.ratecontrol.model.Rule;
import com.oracle.multitenent.ratecontrol.model.Stat;
import com.oracle.multitenent.ratecontrol.util.DbUtil;
import com.oracle.multitenent.ratecontrol.util.HttpUtil;
import com.oracle.multitenent.ratecontrol.util.JsonUtil;
import com.typesafe.config.Config;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Rate Control Server
 * Api endpoints are defined here
 */
public class Server {
    private static final Logger LOGGER = LoggerFactory.getLogger(Server.class);
    private static final int WORKER_POOL_SIZE = 100;
    private static final String BasePath = "/broker/pdbcs/ratecontrol";
    private static final String Master = "master";

    private final Map<String, String> partitions = new HashMap<>();
    private final Map<String, List<Rule>> rules = new HashMap<>();
    private final Map<String, Map<String, Rule>> rulesByName = new HashMap<>();
    private final Vertx vertx;
    private long ruleVersion = 0;

    private Server() {
        vertx = Vertx.vertx(new VertxOptions().setWorkerPoolSize(WORKER_POOL_SIZE));
    }

    private static class Singleton {
        private static final Server instance = new Server();
    }

    public static Server getInstance() {
        return Singleton.instance;
    }

    public void startServer(Config config) {
        partitions.putAll(DbUtil.getPartitions());
        refreshRuleTree(null);
        BatchedStatistics.setMinPublishInterval(config.getInt("statistics.minPublishInterval"));

        Router router = Router.router(vertx);
        addEndpointHandlers(router);
        int port = config.getInt("http.port");

        // Create the HTTP server
        vertx.createHttpServer()
                .requestHandler(router)
                .listen(port)
                .onSuccess(server ->
                        LOGGER.info("HTTP server started : http://localhost:" + server.actualPort())
                );
    }

    private void addEndpointHandlers(Router router) {
        router.get("/").handler(this::getYaml);
        router.route(BasePath + "/*").handler(BodyHandler.create());
        router.get(BasePath + "/rules").handler(this::getRules);
        router.post(BasePath + "/rules").handler(this::addRule);
        router.delete(BasePath + "/rules").handler(this::deleteRule);
        router.post(BasePath + "/refresh").handler(this::refreshRules);
        router.post(BasePath + "/check").handler(this::checkRate);
        router.post(BasePath + "/grant").handler(this::grantToken);
        router.get(BasePath + "/statistics").handler(this::getStatistics);
    }

    /**
     * GET : http://localhost:18082
     * @param routingContext : context for the handling of a request
     */
    private void getYaml(RoutingContext routingContext) {
        try {
            String content = getFileContent("api.yaml");
            routingContext.response()
                    .putHeader("content-type", "text; charset=utf-8")
                    .end(content);
        } catch (Exception e) {
            LOGGER.error("Could not fetch api.yaml", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * GET : http://localhost:18082/broker/pdbcs/ratecontrol/rules?name=TenantsProvisioningRule
     * @param routingContext : context for the handling of a request
     */
    private void getRules(RoutingContext routingContext) {
        try {
            final String partition = getPartition(routingContext);
            final String name = routingContext.request().getParam("name");
            routingContext.response()
                    .putHeader("content-type", "application/json; charset=utf-8")
                    .end(JsonUtil.toJson(DbUtil.getRules(partition, name)));
        } catch (Exception e) {
            LOGGER.error("Could not fetch rules", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * POST : http://localhost:18082/broker/pdbcs/ratecontrol/rules
     * {
     *     "partition": "broker",
     *     "name": "TenantsProvisioningRule",
     *     "priority": 20000,
     *     "isTestRun": false,
     *     "condition": {
     *         "path_0": "tenants",
     *         "method": "POST"
     *     },
     *     "dimension": {
     *         "dimension": "p1"
     *     },
     *     "rate": {
     *         "burst": 5,
     *         "periodMs": 60000
     *     },
     *     "updated": 1616654420392
     * }
     * @param routingContext : context for the handling of a request
     */
    private void addRule(RoutingContext routingContext) {
        try {
            final String partition = getPartition(routingContext);
            final Rule rule = JsonUtil.fromJson(routingContext.getBodyAsString(), Rule.class);
            boolean success = DbUtil.addRule(partition == null ? rule.getPartition() : partition, rule);
            routingContext.response().setStatusCode(success ?
                    HttpUtil.Status.OK.getCode() : HttpUtil.Status.BAD_REQUEST.getCode()).end();
        } catch (Exception e) {
            LOGGER.error("Could not add rule", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * DELETE : http://localhost:18082/broker/pdbcs/ratecontrol/rules?name=TenantsProvisioningRule
     * @param routingContext : context for the handling of a request
     */
    private void deleteRule(RoutingContext routingContext) {
        try {
            final String partition = getPartition(routingContext);
            final String name = routingContext.request().getParam("name");
            if (name == null) {
                routingContext.response().setStatusCode(HttpUtil.Status.BAD_REQUEST.getCode())
                        .end("Invalid rule 'name' in query parameter");
            }
            routingContext.response()
                    .putHeader("content-type", "application/json; charset=utf-8")
                    .end(JsonUtil.toJson(DbUtil.deleteRule(partition, name)));
        } catch (Exception e) {
            LOGGER.error("Could not delete rule", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * POST : http://localhost:18082/broker/pdbcs/ratecontrol/refresh
     * @param routingContext : context for the handling of a request
     */
    private void refreshRules(RoutingContext routingContext) {
        try {
            final String partition = getPartition(routingContext);
            refreshRuleTree(partition);
            routingContext.response()
                    .putHeader("content-type", "application/json; charset=utf-8")
                    .end(JsonUtil.toJson(RuleTree.getRuleTree(partition)));
        } catch (Exception e) {
            LOGGER.error("Error while refreshing RuleTree ", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * GET : http://localhost:18082/broker/pdbcs/ratecontrol/statistics?client=rcserver&name=TenantsProvisioningRule
     * @param routingContext : context for the handling of a request
     */
    private void getStatistics(RoutingContext routingContext) {
        try {
            final String partition = getPartition(routingContext);
            final String client = routingContext.request().getParam("client");
            final String name = routingContext.request().getParam("name");
            routingContext.response()
                    .putHeader("content-type", "application/json; charset=utf-8")
                    .end(JsonUtil.toJson(DbUtil.getStatistics(partition, client, name)));
        } catch (Exception e) {
            LOGGER.error("Error while fetching statistics ", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * POST : http://localhost:18082/broker/pdbcs/ratecontrol/check
     * {
     *     "partition": "broker",
     *     "ip": "http://slc17uhr.us.oracle.com:8080",
     *     "path": "tenants/TENANT1/databases/",
     *     "request_id": "87f69035-f4e4-4606-a2bb-464b06047859",
     *     "access_token": {
     *         "map": {
     *             "tenantName": "PDBCS",
     *             "databaseName": "PDBCS",
     *             "guid": "PDBCS",
     *             "username": "C##CLOUD$SERVICE",
     *             "expiration": "Jan 26, 2021 9:19:10 AM",
     *             "grantTime": "Jan 26, 2021 8:19:10 AM",
     *             "userRoles": [
     *                 {
     *                     "role": "C##ADWC_MONITOR",
     *                     "common": true
     *                 },
     *                 {
     *                     "role": "C##ADWC_ADMIN",
     *                     "common": true
     *                 },
     *                 {
     *                     "role": "C##ADWC_OPERATOR",
     *                     "common": true
     *                 },
     *                 {
     *                     "role": "DV_OWNER",
     *                     "common": false
     *                 },
     *                 {
     *                     "role": "DV_ACCTMGR",
     *                     "common": true
     *                 },
     *                 {
     *                     "role": "DV_PATCH_ADMIN",
     *                     "common": true
     *                 }
     *             ]
     *         }
     *     },
     *     "method": "POST",
     *     "service": "INTERNAL",
     *     "path_parameters": {
     *         "name": [
     *             "TENANT1"
     *         ],
     *         "database": [
     *             "SANDEEP01",
     *             "VASSILI"
     *         ]
     *     },
     *     "query_parameters": {
     *         "mode": [
     *             "hard"
     *         ]
     *     }
     * }
     * @param routingContext : context for the handling of a request
     */
    private void checkRate(RoutingContext routingContext) {
        try {
            final Request req = JsonUtil.fromJson(routingContext.getBodyAsString(), Request.class);
            String partition = getPartition(routingContext);
            if (partition == null) partition = req.getPartition();
            if (!partition.equalsIgnoreCase(req.getPartition())) {
                routingContext.response().setStatusCode(HttpUtil.Status.BAD_REQUEST.getCode())
                        .end("Invalid request partition");
            } else {
                boolean allow = true;
                Rule bestRule = RuleTree.findBestRule(req);
                if (bestRule != null) {
                    allow = bestRule.isTestRun() || RateManagement.allowRequest(bestRule);
                    BatchedStatistics.processedRequest(bestRule, allow);
                }
                routingContext.response().setStatusCode(allow ?
                        HttpUtil.Status.OK.getCode() : HttpUtil.Status.TOO_MANY_REQUEST.getCode()).end();
            }
        } catch (Exception e) {
            LOGGER.error("Error while doing rate check ", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * POST : http://localhost:18082/broker/pdbcs/ratecontrol/grant
     * {
     *     "partition": "broker",
     *     "client_id": "wls-2",
     *     "rule_version": 1616655737649,
     *     "rate_key": "TenantsProvisioningRule",
     *     "allowed": 120,
     *     "blocked": 0,
     *     "time": 1616654420392
     * }
     * @param routingContext : context for the handling of a request
     */
    private void grantToken(RoutingContext routingContext) {
        try {
            final RequestGrant reqGrant = JsonUtil.fromJson(routingContext.getBodyAsString(), RequestGrant.class);
            String partition = getPartition(routingContext);
            if (partition == null) partition = reqGrant.getPartition();
            if (!partition.equalsIgnoreCase(reqGrant.getPartition())) {
                routingContext.response().setStatusCode(HttpUtil.Status.BAD_REQUEST.getCode())
                        .end("Invalid request partition");
            } else {
                if (ruleVersion != reqGrant.getRule_version()) {
                    routingContext.response()
                            .putHeader("content-type", "application/json; charset=utf-8")
                            .end(JsonUtil.toJson(new Grant(ruleVersion, rules.get(partition), null)));
                } else {
                    Stat stat = new Stat(reqGrant.getPartition(), reqGrant.getRate_key(), reqGrant.getClient_id());
                    stat.setAllowed(reqGrant.getAllowed());
                    stat.setBlocked(reqGrant.getBlocked());
                    stat.setTime(new Timestamp(reqGrant.getTime()));
                    DbUtil.publishStatistics(stat);

                    Rule rule = rulesByName.get(reqGrant.getPartition()).get(reqGrant.getRate_key());
                    Grant.Token token = DistributedRateManagement.issueGrant(reqGrant, rule);
                    routingContext.response()
                            .putHeader("content-type", "application/json; charset=utf-8")
                            .end(JsonUtil.toJson(new Grant(ruleVersion, null, token)));
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error occured while fetching Grant", e);
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode()).end();
        }
    }

    /**
     * helper function to get correct partition
     * @param routingContext : context for the handling of a request
     * @return partition
     */
    private String getPartition(RoutingContext routingContext) {
        String partition_key = routingContext.request().getHeader("partition_key");
        if (partition_key == null || partition_key.isEmpty() || !partitions.containsKey(partition_key)) {
            routingContext.response().setStatusCode(HttpUtil.Status.BAD_REQUEST.getCode())
                    .end("Invalid partition_key in the header");
        }
        String partition = partitions.get(partition_key);
        return Master.equalsIgnoreCase(partition) ? null : partition;
    }

    /**
     * helper function to rebuild RuleTree
     * @param partition : application specific partition
     */
    private void refreshRuleTree(String partition) {
        if (partition == null) {
            for (String part : partitions.values()) {
                if (Master.equalsIgnoreCase(part)) continue;
                rules.put(part, DbUtil.getRules(part, null));
                rulesByName.put(part, rules.get(part).stream().collect(Collectors.toMap(Rule::getName, r -> r)));
                RuleTree.prepare(part, rules.get(part));
            }
        } else {
            rules.put(partition, DbUtil.getRules(partition, null));
            rulesByName.put(partition, rules.get(partition).stream().collect(Collectors.toMap(Rule::getName, r -> r)));
            RuleTree.prepare(partition, rules.get(partition));
        }
        RateManagement.reset(partition);
        DistributedRateManagement.reset(partition);
        ruleVersion = System.currentTimeMillis();
    }

    /**
     * Utility function to read file contents
     * @param file file name to be read
     */
    private String getFileContent(String file) throws IOException {
        InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(file);
        byte[] bytes = new byte[inputStream.available() + 1];
        inputStream.read(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }
}

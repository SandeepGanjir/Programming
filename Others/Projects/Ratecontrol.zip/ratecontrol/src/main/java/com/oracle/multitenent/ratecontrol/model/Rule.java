package com.oracle.multitenent.ratecontrol.model;

import com.oracle.multitenent.ratecontrol.util.JsonUtil;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Hashtable;

/**
 * This is a model to describe Rate Control Rules
 */
@XmlRootElement
public class Rule implements Serializable {
    private static final long serialVersionUID = -436119276569069089L;

    // Unique App partition name
    private final String partition;

    // Unique Rule Name
    private final String name;

    // Priority - set priority to choose one rule if request satisfies several conditions
    private final int priority;

    // if rule is in test mode - not to rate limit, but collect statistics only
    boolean isTestRun = false;

    // Condition - identify subset of JSON requests to apply rate limit
    private final Hashtable<String, String> condition;

    // Dimension - define per which JSON attribute of request rate should be counted for
    private final Hashtable<String, String> dimension;

    // definition of rate to be applied
    private final Rate rate;

    // Timestamp millis of last rule update
    private long updated;

    /**
     * Constructor to pass query results to object
     */
    public Rule(String partition, String name, int priority, boolean isTestRun, String condition, String dimension, String rate, long updated) {
        this.partition = partition;
        this.name = name;
        this.priority = priority;
        this.isTestRun = isTestRun;
        this.condition = JsonUtil.fromJson(condition, Hashtable.class);
        this.dimension = JsonUtil.fromJson(dimension, Hashtable.class);
        this.rate = JsonUtil.fromJson(rate, Rate.class);
        this.updated = updated;
    }


    /**
     * Attribute getters and setters for Serialization
     */

    public String getPartition() {
        return partition;
    }

    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    public Hashtable<String, String> getCondition() {
        return condition;
    }

    public Hashtable<String, String> getDimension() {
        return dimension;
    }

    public Rate getRate() {
        return rate;
    }

    public long getUpdated() {
        return updated;
    }

    public boolean isTestRun() {
        return isTestRun;
    }

    public void setTestRun(boolean testRun) {
        isTestRun = testRun;
    }

    public String conditionString() {
        return JsonUtil.toJson(condition);
    }

    public String dimensionString() {
        return JsonUtil.toJson(dimension);
    }

    public String rateString() {
        return JsonUtil.toJson(rate);
    }

    public static class Rate {
        int burst;
        int periodMs;

        public Rate(int burst, int periodMs) {
            this.burst = burst;
            this.periodMs = periodMs;
        }

        public int getBurst() {
            return burst;
        }

        public int getPeriodMs() {
            return periodMs;
        }
    }
}

package com.oracle.multitenent.ratecontrol.model;

import io.vertx.core.json.JsonObject;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is a model to describe Rate Control Rate Check Request
 */
@XmlRootElement
public class Request implements Serializable {
    private static final long serialVersionUID = -436119276569069090L;

    // Unique App partition name
    private final String partition;

    // Ip form where request originated
    private final String ip;

    // relative URL path form context root
    private final String path;

    // unique request Id of the request
    private final String request_id;

    // decoded access token from request
    private JsonObject access_token;

    // Http request type form Enum HttpClient.RequestType
    private String method;

    // String service name from Enum MicroService.ServiceType
    private String service;

    // Parameters defined in request URL path
    private Map<String, List<String>> path_parameters;

    // Named Parameters attached to the end of request url
    private Map<String, List<String>> query_parameters;

    public Request(String partition, String ip, String path, String request_id,
                   JsonObject access_token, String method, String service,
                   Map<String, List<String>> pathParameters,
                   Map<String, List<String>> queryParameters) {
        this.partition = partition;
        this.ip = ip;
        this.path = path;
        this.request_id = request_id;
        this.access_token = access_token;
        this.method = method;
        this.service = service;
        this.path_parameters = pathParameters;
        this.query_parameters = queryParameters;
    }

    public String getPartition() {
        return partition;
    }

    public Map<String, String> flatMap() {
        Map<String, String> result = new HashMap<>();
        result.put("ip", ip);
        result.put("request_id", request_id);
        result.put("method", method);
        result.put("service", service);
        String[] paths = path.split("/");
        for (int i = 0; i < paths.length; i++) {
            result.put("path_" + i, paths[i]);
        }
        for (String ppKey : path_parameters.keySet()) {
            List<String> values = path_parameters.get(ppKey);
            if (values != null && !values.isEmpty())
                result.put("path." + ppKey, path_parameters.get(ppKey).get(0));
        }
        for (String qpKey : query_parameters.keySet()) {
            List<String> values = query_parameters.get(qpKey);
            if (values != null && !values.isEmpty())
                result.put("path." + qpKey, query_parameters.get(qpKey).get(0));
        }
        return result;
    }
}

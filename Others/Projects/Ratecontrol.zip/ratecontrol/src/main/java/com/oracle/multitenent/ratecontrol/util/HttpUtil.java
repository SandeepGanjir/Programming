package com.oracle.multitenent.ratecontrol.util;

import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Utility Class to make Http calls to Rate Control Broker
 */
public class HttpUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtil.class);

    public static HttpURLConnection doHttpRequest(final String urlStr, final String requestMethod, String token,
                                           final String partitionKey, final String body) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(urlStr);
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setInstanceFollowRedirects(true);
            if (requestMethod != null) {
                connection.setRequestMethod(requestMethod);
            }
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            if (token != null) connection.setRequestProperty("Authorization", "Bearer " + token);
            if (partitionKey != null) connection.setRequestProperty("partition_key", partitionKey);
            if (body != null) {
                OutputStreamWriter wr = null;
                if (requestMethod != null && !"GET".equals(requestMethod) && !"DELETE".equals(requestMethod)) {
                    wr = new OutputStreamWriter(connection.getOutputStream());
                    wr.write(body);
                    wr.flush();
                }
            }
            connection.connect();
        } catch (Exception e) {
            LOGGER.error("Failed to get response from RateControl Server.", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return connection;
    }

    public static String getResponseObject(HttpURLConnection connection) throws IOException {
        int code = connection.getResponseCode();
        InputStream is = (code >= Status.OK.getCode() && code < Status.BAD_REQUEST.getCode()) ?
                connection.getInputStream() : connection.getErrorStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuffer sb = new StringBuffer();
        String line = null;
        while ((line = reader.readLine()) != null)
            sb.append(line);
        String responseStr;
        try {
            responseStr = sb.toString();
        } catch (Exception e) {
            responseStr = connection.getResponseMessage();
        }
        return responseStr;
    }

    public enum Status {
        OK(HttpURLConnection.HTTP_OK),
        BAD_REQUEST(HttpURLConnection.HTTP_BAD_REQUEST),
        TOO_MANY_REQUEST(429),
        INTERNAL_ERROR(HttpURLConnection.HTTP_INTERNAL_ERROR);

        private final int statusCode;

        Status(int statusCode) {
            this.statusCode = statusCode;
        }

        public int getCode() {
            return statusCode;
        }
    }
}

package com.oracle.multitenent.ratecontrol.util;

import com.oracle.multitenent.ratecontrol.model.Rule;
import com.oracle.multitenent.ratecontrol.model.Stat;
import com.typesafe.config.Config;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;
import org.sqlite.util.StringUtils;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Utility Class for interacting with DB
 */
public class DbUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbUtil.class);
    private static final String RULE_TABLE = "centralcdb_rate_control_rules$";
    private static final String STATISTICS_TABLE = "centralcdb_rate_control_statistics$";
    private static DbUtil instance;

    private final String URL;
    private final String Username;
    private final String Password;
    private Connection Conn;

    private DbUtil(String url, String user, String pwd) {
        URL = url;
        Username = user;
        Password = pwd;
    }

    private Connection getConnection() throws SQLException {
        if (Conn == null || Conn.isClosed()) {
            Conn = DriverManager.getConnection(URL, Username, Password);
        }
        return Conn;
    }

    public static void init(Config config) {
        String path = Files.exists(Paths.get(config.getString("path"))) ? config.getString("path") : "";
        String url = config.getString("jdbc") + path + config.getString("name");
        instance = new DbUtil(url, config.getString("username"), config.getString("password"));
    }

    public static Map<String, String> getPartitions() {
        Map<String, String> partitions = new HashMap<>();
        String sql = "select key, name from centralcdb_rate_control_partition$";
        LOGGER.info("Getting partitions from Db : " + sql);
        try {
            PreparedStatement stmt = instance.getConnection().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                partitions.put(rs.getString("key"), rs.getString("name"));
            }
            stmt.close();
        } catch (SQLException err) {
            LOGGER.error(err);
        }
        return partitions;
    }

    public static List<Rule> getRules(String partition, String name) {
        final List<Rule> rules = new ArrayList<>();

        String sql = "select partition, name, priority, test, condition, dimension, rate, updated from " + RULE_TABLE;
        List<String> conditions = new ArrayList<>();
        if (partition != null) conditions.add("partition = ?");
        if (name != null) conditions.add("name = ?");
        if (!conditions.isEmpty()) {
            sql += " where " + StringUtils.join(conditions, " and ");
        }
        LOGGER.info("Getting rules from Db : " + sql);
        try {
            PreparedStatement stmt = instance.getConnection().prepareStatement(sql);
            int i = 1;
            if (partition != null) stmt.setString(i++, partition);
            if (name != null) stmt.setString(i++, name);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                i = 1;
                Rule rule = new Rule(rs.getString(i++), rs.getString(i++), rs.getInt(i++),
                        rs.getInt(i++) != 0, rs.getString(i++),
                        rs.getString(i++), rs.getString(i++), rs.getTimestamp(i++).getTime());
                rules.add(rule);
            }
            stmt.close();
        } catch (SQLException err) {
            LOGGER.error(err);
        }
        return rules;
    }

    public static boolean addRule(String partition, Rule rule) {
        boolean success = false;
        String sql = "insert or replace into " + RULE_TABLE +
                " (partition, name, priority, test, condition, dimension, rate, updated) values(?,?,?,?,?,?,?,?)";
        if (!partition.equalsIgnoreCase(rule.getPartition()))
            throw new RuntimeException("Invalid rule partition");
        LOGGER.info("Adding rule : " + JsonUtil.toJson(rule));
        try {
            PreparedStatement stmt = instance.getConnection().prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, rule.getPartition());
            stmt.setString(i++, rule.getName());
            stmt.setInt(i++, rule.getPriority());
            stmt.setInt(i++, rule.isTestRun() ? 1 : 0);
            stmt.setString(i++, rule.conditionString());
            stmt.setString(i++, rule.dimensionString());
            stmt.setString(i++, rule.rateString());
            stmt.setTimestamp(i++, rule.getUpdated() <= 0 ?
                    new Timestamp(System.currentTimeMillis()) : new Timestamp(rule.getUpdated()));
            success = stmt.executeUpdate() > 0;
            stmt.close();
        } catch (SQLException err) {
            LOGGER.error(err);
        }
        return success;
    }

    public static boolean deleteRule(String partition, String name) {
        boolean success = false;
        String sql = "delete from " + RULE_TABLE;
        List<String> conditions = new ArrayList<>();
        if (partition != null) conditions.add("partition = ?");
        if (name != null) conditions.add("name = ?");
        if (!conditions.isEmpty()) {
            sql += " where " + StringUtils.join(conditions, " and ");
        }
        LOGGER.info("Deleting rule : " + sql);
        try {
            PreparedStatement stmt = instance.getConnection().prepareStatement(sql);
            int i = 1;
            if (partition != null) stmt.setString(i++, partition);
            if (name != null) stmt.setString(i++, name);
            success = stmt.executeUpdate() > 0;
            stmt.close();
        } catch (SQLException err) {
            LOGGER.error(err);
        }
        return success;
    }

    public static boolean publishStatistics(Stat stat) {
        if (stat.getAllowed() + stat.getBlocked() <= 0)
            return false;
        boolean success = false;
        String sql = "insert into " + STATISTICS_TABLE +
                " (partition, rate_key, client_id, allowed, blocked, ts) values(?,?,?,?,?,?)";
        LOGGER.info("Writing statistics : " + JsonUtil.toJson(stat));
        try {
            PreparedStatement stmt = instance.getConnection().prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, stat.getPartition());
            stmt.setString(i++, stat.getRate_key());
            stmt.setString(i++, stat.getClient_id());
            stmt.setInt(i++, stat.getAllowed());
            stmt.setInt(i++, stat.getBlocked());
            stmt.setTimestamp(i++, stat.getTime());
            success = stmt.executeUpdate() > 0;
            stmt.close();
        } catch (SQLException err) {
            LOGGER.error(err);
        }
        return success;
    }

    public static List<Stat> getStatistics(String partition, String client, String name) {
        final List<Stat> stats = new ArrayList<>();

        String sql = "select partition, rate_key, client_id, allowed, blocked, ts from " + STATISTICS_TABLE;
        List<String> conditions = new ArrayList<>();
        if (partition != null) conditions.add("partition = ?");
        if (name != null) conditions.add("rate_key = ?");
        if (client != null) conditions.add("client_id = ?");
        if (!conditions.isEmpty()) {
            sql += " where " + StringUtils.join(conditions, " and ");
        }
        LOGGER.info("Getting statistics from Db : " + sql);
        try {
            PreparedStatement stmt = instance.getConnection().prepareStatement(sql);
            int i = 1;
            if (partition != null) stmt.setString(i++, partition);
            if (name != null) stmt.setString(i++, name);
            if (client != null) stmt.setString(i++, client);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                i = 1;
                Stat stat = new Stat(rs.getString(i++), rs.getString(i++), rs.getString(i++));
                stat.setAllowed(rs.getInt(i++));
                stat.setBlocked(rs.getInt(i++));
                stat.setTime(rs.getTimestamp(i++));
                stats.add(stat);
            }
            stmt.close();
        } catch (SQLException err) {
            LOGGER.error(err);
        }
        return stats;
    }
}

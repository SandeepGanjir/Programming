package com.oracle.multitenent.ratecontrol;

import com.oracle.multitenent.ratecontrol.server.Server;
import com.oracle.multitenent.ratecontrol.util.DbUtil;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Starting point for the RateControl Server Application
 * > java -Xmx1024m -jar ratecontrol.jar
 */
public class Main {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        LOGGER.info("Loading Config");
        Config config = ConfigFactory.parseResources("default.conf");

        LOGGER.info("Initialising Db connection");
        initializeDbFile(config);
        DbUtil.init(config.getConfig("db"));

        LOGGER.info("Starting Server");
        Server server = Server.getInstance();
        server.startServer(config);

        // ToDo: Remove this - Kill after fixed delay
        //Executors.newScheduledThreadPool(1).schedule(() -> System.exit(0), 600, TimeUnit.SECONDS);
    }

    private static void initializeDbFile(Config config) {
        String fileName = config.getString("db.name");
        if (Files.exists(Paths.get(config.getString("db.path") + fileName))
                || Files.exists(Paths.get(fileName)))
            return;
        try {
            InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
            byte[] buffer = new byte[inputStream.available() + 1];
            inputStream.read(buffer);
            File targetFile = new File(fileName);
            OutputStream outStream = new FileOutputStream(targetFile);
            outStream.write(buffer);
        } catch (Exception e) {
            LOGGER.error("DB may not be initialized", e);
        }
    }
}

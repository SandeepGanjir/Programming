package com.oracle.multitenent.ratecontrol.server;

import com.oracle.multitenent.ratecontrol.model.Grant;
import com.oracle.multitenent.ratecontrol.model.RequestGrant;
import com.oracle.multitenent.ratecontrol.model.Rule;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * DistributedRateManagement : Class for distributed rate management
 * to be used for distributed rate control.
 */
class DistributedRateManagement {
    private static final Logger LOGGER = LoggerFactory.getLogger(DistributedRateManagement.class);
    private static final Hashtable<String, Hashtable<String, DistributedRateManagement>> rateManagers = new Hashtable<>();

    private final ConcurrentLinkedQueue<RequestGrant> servedRequests;
    private final Map<String, Long> clientLastServed;
    private final int maxAllowed;
    private final int timeInterval;
    private int allowedSoFar = 0;
    private int blockedSoFar = 0;

    private DistributedRateManagement(Rule rule) {
        this.servedRequests = new ConcurrentLinkedQueue<>();
        this.clientLastServed = new HashMap<>();
        this.maxAllowed = rule.getRate().getBurst();
        this.timeInterval = rule.getRate().getPeriodMs();
    }

    private synchronized Grant.Token provideGrant(RequestGrant servedReq, Rule rule) {
        updateStats(servedReq);
        if (allowedSoFar < maxAllowed) {
            // Case where we are still within allowed limit
            int activeClients = clientLastServed.size() + 1;
            long allowedTime = System.currentTimeMillis() + timeInterval / 5;
            int remaining = maxAllowed - allowedSoFar;
            int minAllowed = Math.max(Math.min(maxAllowed / 50, remaining), 1);
            int allowed = Math.max(Math.min(remaining / activeClients, maxAllowed / 5), minAllowed);
            return new Grant.Token(servedReq.getRate_key(), allowed, allowedTime);
        } else {
            // Case where we have to block requests till we free up
            return new Grant.Token(servedReq.getRate_key(), getBlockedTime());
        }
    }

    private synchronized void updateStats(RequestGrant servedReq) {
        if (servedReq!=null) {
            servedRequests.offer(servedReq);
            allowedSoFar += servedReq.getAllowed();
            blockedSoFar += servedReq.getBlocked();
            clientLastServed.put(servedReq.getClient_id(), servedReq.getTime());
        }
        long thresholdTime = System.currentTimeMillis() - timeInterval;
        while (!servedRequests.isEmpty() && servedRequests.peek().getTime() < thresholdTime) {
            RequestGrant requestGrant = servedRequests.poll();
            allowedSoFar -= requestGrant.getAllowed();
            blockedSoFar -= requestGrant.getBlocked();
        }
        // thresholdTime = System.currentTimeMillis() - 3 * timeInterval;
        for (String client: clientLastServed.keySet()) {
            if (clientLastServed.get(client) < thresholdTime)
                clientLastServed.remove(client);
        }
    }

    private long getBlockedTime() {
        long allowed = allowedSoFar;
        long blockedTime = -1;
        for (RequestGrant servedReq : servedRequests) {
            allowed -= servedReq.getAllowed();
            blockedTime = servedReq.getTime();
            if (allowed < maxAllowed)
                break;
        }
        return blockedTime + timeInterval;
    }

    static Grant.Token issueGrant(RequestGrant servedReq, Rule rule) {
        DistributedRateManagement rm = rateManagers.computeIfAbsent(servedReq.getPartition(),
                p -> new Hashtable<>()).computeIfAbsent(servedReq.getRate_key(), n -> new DistributedRateManagement(rule));
        return rm.provideGrant(servedReq, rule);
    }

    static void reset(String partition) {
        if (partition == null)
            rateManagers.clear();
        else
            rateManagers.remove(partition);
    }
}

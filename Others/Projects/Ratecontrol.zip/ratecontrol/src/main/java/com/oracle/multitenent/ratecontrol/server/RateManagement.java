package com.oracle.multitenent.ratecontrol.server;

import com.oracle.multitenent.ratecontrol.model.Rule;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.util.Hashtable;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * RateManagement : Class for rates management for different rules
 */
class RateManagement {
    private static final Logger LOGGER = LoggerFactory.getLogger(RateManagement.class);
    private static final Hashtable<String, Hashtable<String, RateManagement>> rateManagers = new Hashtable<>();

    private final ConcurrentLinkedQueue<ServedStat> servedRequests;
    private final int maxAllowed;
    private final int timeInterval;
    private int allowedSoFar;
    private int blockedSoFar;

    private RateManagement(Rule rule) {
        this.servedRequests = new ConcurrentLinkedQueue<>();
        this.maxAllowed = rule.getRate().getBurst();
        this.timeInterval = rule.getRate().getPeriodMs();
        this.allowedSoFar = 0;
        this.blockedSoFar = 0;
    }

    private synchronized boolean doAllow() {
        long ts = System.currentTimeMillis();
        while (servedRequests.peek() != null &&
                servedRequests.peek().timeMillis + timeInterval < ts) {
            ServedStat servedStat = servedRequests.poll();
            allowedSoFar -= servedStat.allows;
            blockedSoFar -= servedStat.blocks;
        }
        if (allowedSoFar < maxAllowed) {
            servedRequests.offer(new ServedStat(1,0, ts));
            allowedSoFar++;
            return true;
        } else {
            // ToDo: May wanna track blocked request
            //  servedRequests.offer(new ServedStat(0,1, ts));
            blockedSoFar++;
            return false;
        }
    }

    static boolean allowRequest(Rule rule) {
        RateManagement rm = rateManagers.computeIfAbsent(rule.getPartition(), p -> new Hashtable<>())
                .computeIfAbsent(rule.getName(), name -> new RateManagement(rule));
        return rm.doAllow();
    }

    static void reset(String partition) {
        if (partition == null)
            rateManagers.clear();
        else
            rateManagers.remove(partition);
    }

    private class ServedStat {
        private final int allows;
        private final int blocks;
        private final long timeMillis;

        private ServedStat(int allows, int blocks, long timeMillis) {
            this.allows = allows;
            this.blocks = blocks;
            this.timeMillis = timeMillis;
        }
    }
}

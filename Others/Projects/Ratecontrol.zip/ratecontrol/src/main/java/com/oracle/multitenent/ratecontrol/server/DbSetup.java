package com.oracle.multitenent.ratecontrol.server;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

/**
 * For initial setup of Database
 * > java -cp ratecontrol.jar com.oracle.multitenent.ratecontrol.server.DbSetup
 * alternatively use ratecontrol_tables.sql
 */
public class DbSetup {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbSetup.class);

    public static void main(String[] args) {
        Config config = ConfigFactory.parseResources("default.conf").getConfig("db");

        String path = Files.exists(Paths.get(config.getString("path"))) ? config.getString("path") : "";
        String url = config.getString("jdbc") + path + config.getString("name");
        try {
            Connection conn = DriverManager.getConnection(url, config.getString("username"), config.getString("password"));
            createDatabase(conn);
            createTables(conn);
            LOGGER.warn("DB location is : " + System.getProperty("user.dir") + "/" + path + config.getString("name"));
        } catch (SQLException e) {
            LOGGER.error(e);
        }
    }

    private static void createDatabase(Connection conn) {
        try {
            final Set<String> Tables = new HashSet<>();
            if (conn != null) {
                DatabaseMetaData meta = conn.getMetaData();
                LOGGER.info("The driver name is " + meta.getDriverName());

                String[] types = {"TABLE"};
                ResultSet tables = meta.getTables(null, null, "%", types);
                while (tables.next()) {
                    Tables.add(tables.getString("TABLE_NAME"));
                }
                LOGGER.info("Our database has tables : " + Tables.toString());
            }
        } catch (SQLException e) {
            LOGGER.error(e);
        }
    }

    private static void createTables(Connection conn) {
        String[] scripts = {
                "create table if not exists centralcdb_rate_control_partition$ (\n" +
                        "  name          varchar2(64),\n" +
                        "  key           varchar2(64),\n" +
                        "  primary key   ( name )\n" +
                        ")",
                "insert into centralcdb_rate_control_partition$ (name, key) " +
                        "values ('master','op0jzrpu8ywfriwqre3hitjyfzc711dr')",
                "insert into centralcdb_rate_control_partition$ (name, key) " +
                        "values ('broker','uuc4vudjjl9pnuupd8owyi8xh7rubvnz')",
                "insert into centralcdb_rate_control_partition$ (name, key) " +
                        "values ('oml','1zujvfk2dfce97670ol472khknm4cyyl')",
                "insert into centralcdb_rate_control_partition$ (name, key) " +
                        "values ('graph','2peiigzz17idmyu8solbwzxtgcpprbww')",
                "create table if not exists centralcdb_rate_control_rules$ (\n" +
                        "  id            number IDENTITY(1,1),\n" +
                        "  partition     varchar2(64),\n" +
                        "  name          varchar2(256),\n" +
                        "  priority      number,\n" +
                        "  test          number default 0,\n" +
                        "  condition     clob,\n" +
                        "  dimension     clob,\n" +
                        "  rate          clob,\n" +
                        "  updated       timestamp,\n" +
                        "  primary key   ( partition, name ),\n" +
                        "  foreign key   ( partition ) references centralcdb_rate_control_partition$ ( name )\n" +
                        ")",
                "create table if not exists centralcdb_rate_control_statistics$ (\n" +
                        "  id          number IDENTITY(1,1),\n" +
                        "  partition   varchar2(64),\n" +
                        "  rate_key    varchar(256) not null,\n" +
                        "  client_id   varchar(50),\n" +
                        "  allowed     number,\n" +
                        "  blocked     number,\n" +
                        "  ts          timestamp,\n" +
                        "  foreign key ( partition ) references centralcdb_rate_control_partition$ ( name )\n" +
                        ")"
        };
        for (String sql : scripts) {
            try {
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.execute();
                stmt.close();
            } catch (SQLException e) {
                LOGGER.info(e);
            }
        }
    }
}

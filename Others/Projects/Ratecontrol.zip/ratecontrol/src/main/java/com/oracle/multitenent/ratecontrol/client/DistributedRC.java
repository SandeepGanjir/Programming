package com.oracle.multitenent.ratecontrol.client;

import com.oracle.multitenent.ratecontrol.common.RuleTree;
import com.oracle.multitenent.ratecontrol.model.Grant;
import com.oracle.multitenent.ratecontrol.model.Request;
import com.oracle.multitenent.ratecontrol.model.RequestGrant;
import com.oracle.multitenent.ratecontrol.model.Rule;
import com.oracle.multitenent.ratecontrol.util.HttpUtil;
import com.oracle.multitenent.ratecontrol.util.JsonUtil;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Hashtable;
import java.util.List;

/**
 * DistributedRC : Class for managing client side rate control in distributed rate control
 * Manages tokens by communicating with rate control server
 */
class DistributedRC {
    private static final Logger LOGGER = LoggerFactory.getLogger(DistributedRC.class);
    private static final Hashtable<String, DistributedRC> rateManagers = new Hashtable<>();
    private static final int TOKEN_REFRESH_THRESHOLD = 90;

    private static String serverGrantUrl;
    private static String partition_name;
    private static String partition_key;
    private static String client_id;
    private static List<Rule> rules;
    private static long ruleVersion = -1;

    private final String rate_key;
    private Grant.Token token;
    private int allowedSoFar;
    private int blockedSoFar;

    private DistributedRC(String rate_key) {
        this.rate_key = rate_key;
        this.token = null;
        this.allowedSoFar = 0;
        this.blockedSoFar = 0;
    }

    static void init(String grantUrl, String partition, String partitionKey, String clientId) {
        serverGrantUrl = grantUrl;
        partition_name = partition;
        partition_key = partitionKey;
        client_id = clientId;
        requestGrant(null, 0, 0);
    }

    static boolean allowRequest(Request request) {
        do {
            try {
                Rule bestRule = RuleTree.findBestRule(request);
                if (bestRule != null && !bestRule.isTestRun()) {
                    DistributedRC rm = rateManagers.computeIfAbsent(bestRule.getName(), DistributedRC::new);
                    return rm.doAllow();
                }
                return true;
            } catch (Exception e) {
                // Do Nothing
            }
        } while (true);
    }

    private static synchronized Grant.Token requestGrant(String rate_key, int allowed, int blocked) {
        RequestGrant requestGrant = new RequestGrant(partition_name, client_id, ruleVersion,
                rate_key, allowed, blocked, System.currentTimeMillis());
        HttpURLConnection conn = HttpUtil.doHttpRequest(serverGrantUrl, "POST",
                null, partition_key, JsonUtil.toJson(requestGrant));
        try {
            if (conn != null && conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                Grant grant = JsonUtil.fromJson(HttpUtil.getResponseObject(conn), Grant.class);
                if (ruleVersion != grant.getRule_version()) {
                    rules = grant.getRules();
                    ruleVersion = grant.getRule_version();
                    // ToDo: publish non empty stats from rateManagers to Server
                    rateManagers.clear();
                    RuleTree.prepare(partition_name, rules);
                    LOGGER.info("RuleTree initialized with rule version : " + ruleVersion);
                } else {
                    LOGGER.info("Received grant token : " + JsonUtil.toJson(grant.getToken()));
                    return grant.getToken();
                }
            } else {
                LOGGER.error("Unable to get Grant from rate control server");
            }
        } catch (IOException e) {
            LOGGER.error("Unable to get correct response from rate control server", e);
        }
        return null;
    }

    private synchronized void reloadToken() {
        token = requestGrant(rate_key, allowedSoFar, blockedSoFar);
        allowedSoFar = 0;
        blockedSoFar = 0;
    }

    private synchronized boolean doAllow() {
        boolean allow = true;
        long ts = System.currentTimeMillis();
        if (token == null || (token.getBlock_expiration() < ts &&
                (token.getPass_expiration() < ts || token.getPass_allowed() <= allowedSoFar))) {
            // Null or Expired Token -> Request New Token
            reloadToken();
            if (token == null)
                throw new RuntimeException("Refreshed Rule Tree");
        }
        if (token.getBlock_expiration() > 0 && token.getBlock_expiration() > ts) {
            // Blocked so return false
            allow = false;
            blockedSoFar++;
        } else {
            // No longer Blocked, so check if we can allow
            allow = true;
            allowedSoFar++;
            if (allowedSoFar * 100 > token.getPass_allowed() * TOKEN_REFRESH_THRESHOLD) {
                // Async refresh Token once we have used up TOKEN_REFRESH_THRESHOLD % of allowed
                new Thread(this::reloadToken).start();
            }
        }
        return allow;
    }
}

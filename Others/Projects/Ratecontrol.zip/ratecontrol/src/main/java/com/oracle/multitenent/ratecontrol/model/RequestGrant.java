package com.oracle.multitenent.ratecontrol.model;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * This is a model to describe Rate Control Rate Grant Request Object
 */
@XmlRootElement
public class RequestGrant implements Serializable {
    private static final long serialVersionUID = -436119276569069092L;

    // Unique App partition name
    private final String partition;

    // Client Id of the server form where rcClient made the request
    private String client_id;

    // epoc time of last rule modified time, can be 0 (=null) if client don't have rules yet
    private long rule_version;

    // Consistent hash of rate control rule so that server and client can communicate
    private String rate_key;

    // Number of requests allowed by the rcClient for this rule since last posted
    private int allowed;

    // Number of requests blocked by the rcClient for this rule since last posted
    private int blocked;

    // Timestamp millis of request
    private long time;

    public RequestGrant(String partition, String client_id, long rule_version,
                        String rate_key, int allowed, int blocked, long time) {
        this.partition = partition;
        this.client_id = client_id;
        this.rule_version = rule_version;
        this.rate_key = rate_key;
        this.allowed = allowed;
        this.blocked = blocked;
        this.time = time;
    }

    public String getPartition() {
        return partition;
    }

    public String getClient_id() {
        return client_id;
    }

    public long getRule_version() {
        return rule_version;
    }

    public String getRate_key() {
        return rate_key;
    }

    public int getAllowed() {
        return allowed;
    }

    public int getBlocked() {
        return blocked;
    }

    public long getTime() {
        return time;
    }
}

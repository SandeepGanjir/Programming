package com.oracle.multitenent.ratecontrol.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonUtil {
    public static <T> String toJson(T obj) {
        Gson gson = new GsonBuilder().create();
        return gson.toJson(obj);
    }

    public static <T> T fromJson(String str, Class<T> classOfT) {
        Gson gson = new GsonBuilder().create();
        return gson.fromJson(str, classOfT);
    }
}

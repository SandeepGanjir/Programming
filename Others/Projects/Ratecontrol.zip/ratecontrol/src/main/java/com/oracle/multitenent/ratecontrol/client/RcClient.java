package com.oracle.multitenent.ratecontrol.client;

import com.oracle.multitenent.ratecontrol.model.Request;
import com.oracle.multitenent.ratecontrol.util.HttpUtil;
import com.oracle.multitenent.ratecontrol.util.JsonUtil;
import io.vertx.core.Vertx;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Single point of Contact for all Rate Control
 * End users should initialize this using
 * initDirect(ratecontrolServer_lb, partition_key) for direct rate control OR
 * initDelegated(ratecontrolServer_lb, partitionKey, partition, client_id) for delegated rate control
 */
public class RcClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(RcClient.class);
    private static final String CHECK_RATE_ENDPOINT = "/broker/pdbcs/ratecontrol/check";
    private static final String GRANT_TOKEN_ENDPOINT = "/broker/pdbcs/ratecontrol/grant";
    private static RcClient instance;

    private final String ratecontrol_lb;
    private final String partition_key;
    private final boolean isDelegatedMode;

    private RcClient(String ratecontrol_lb, boolean isDelegatedMode,
                     String partition_key, String partition, String client_id) {
        this.ratecontrol_lb = ratecontrol_lb;
        this.isDelegatedMode = isDelegatedMode;
        this.partition_key = partition_key;

        if (this.isDelegatedMode) {
            DistributedRC.init(ratecontrol_lb + GRANT_TOKEN_ENDPOINT, partition, partition_key, client_id);
        }
    }

    public static void initDirect(String ratecontrol_lb, String partitionKey) {
        instance = new RcClient(ratecontrol_lb, false, partitionKey, null, null);
    }

    public static void initDelegated(String ratecontrol_lb, String partitionKey, String partition, String client_id) {
        instance = new RcClient(ratecontrol_lb, true, partitionKey, partition, client_id);
    }

    public static boolean allowRequest(Request request) {
        return instance.handleRequest(request);
    }

    private boolean handleRequest(Request request) {
        if (isDelegatedMode) {
            return DistributedRC.allowRequest(request);
        } else {
            String url = ratecontrol_lb + CHECK_RATE_ENDPOINT;
            HttpURLConnection conn = HttpUtil.doHttpRequest(url, "POST",
                    null, partition_key, JsonUtil.toJson(request));
            try {
                if (conn != null && conn.getResponseCode() == HttpUtil.Status.TOO_MANY_REQUEST.getCode())
                    return false;
            } catch (IOException e) {
                LOGGER.error("Unable to get response form rate control server", e);
            }
            return true;
        }
    }

    // for testing > java -cp ratecontrol.jar com.oracle.multitenent.ratecontrol.client.RcClient
    public static void main(String[] args) {
        initDirect("http://localhost:18082", "uuc4vudjjl9pnuupd8owyi8xh7rubvnz");
        initDelegated("http://localhost:18082", "uuc4vudjjl9pnuupd8owyi8xh7rubvnz", "broker", "wls-1");

        final int port = 15432;
        Vertx vertx = Vertx.vertx();
        Router router = Router.router(vertx);
        router.route("/*").handler(BodyHandler.create());
        router.route("/*").handler(RcClient::requestHandler);
        // Create the HTTP server
        vertx.createHttpServer()
                .requestHandler(router)
                .listen(port)
                .onSuccess(server ->
                        LOGGER.info("HTTP server started : http://localhost:" + port)
                );
    }

    private static void requestHandler(RoutingContext routingContext) {
        try {
            boolean allow = instance.handleRequest(JsonUtil.fromJson(routingContext.getBodyAsString(), Request.class));
            routingContext.response().setStatusCode(allow ?
                    HttpUtil.Status.OK.getCode() : HttpUtil.Status.TOO_MANY_REQUEST.getCode()).end();
        } catch (Exception e) {
            routingContext.response().setStatusCode(HttpUtil.Status.INTERNAL_ERROR.getCode())
                    .end("Error while doing delegated rate check : " + e.getMessage());
        }
    }
}

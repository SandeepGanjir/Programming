package com.oracle.multitenent.ratecontrol.common;

import com.oracle.multitenent.ratecontrol.model.Request;
import com.oracle.multitenent.ratecontrol.model.Rule;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * RuleTree : Trie structure based on conditions for efficient Rule matching algorithm
 */
public class RuleTree {
    private static final Logger LOGGER = LoggerFactory.getLogger(RuleTree.class);
    private static final Hashtable<String, RuleTree> roots = new Hashtable<>();

    private final String conditionClause;
    private final Map<String, RuleTree> subtree;
    private final Rule rule;

    private RuleTree(List<Rule> rules) {
        this.conditionClause = getHighestFrequencyCondition(rules);

        if (conditionClause == null) {
            this.rule = getHighestPriorityRule(rules);
            this.subtree = null;
            if (rules.size() > 1)
                LOGGER.warn("We shouldn't have multiple rules with exact same condition : " + rules.stream().map(Rule::getName).collect(Collectors.joining()));
        } else {
            this.rule = null;
            this.subtree = buildSubtree(rules);
        }
    }

    private String getHighestFrequencyCondition(List<Rule> rules) {
        Map<String, Integer> conditionFrequency = new HashMap<>();
        String mostFreqCondition = null;
        int maxfreq = 0;
        for (Rule rule : rules) {
            for (String condition : rule.getCondition().keySet()) {
                int count = conditionFrequency.computeIfAbsent(condition, c -> 0) + 1;
                conditionFrequency.put(condition, count);
                if (maxfreq < count) {
                    mostFreqCondition = condition;
                    maxfreq = count;
                }
            }
        }
        return mostFreqCondition;
    }

    private Map<String, RuleTree> buildSubtree(List<Rule> rules) {
        Map<String, RuleTree> subtree = new HashMap<>();
        Map<String, List<Rule>> rulesByConditionVal = new HashMap<>();
        for (Rule rule : rules) {
            List<Rule> subList = rulesByConditionVal.computeIfAbsent(
                    rule.getCondition().get(conditionClause), v -> new ArrayList<>());
            rule.getCondition().remove(conditionClause);
            subList.add(rule);
        }
        for (String key : rulesByConditionVal.keySet()) {
            subtree.put(key, new RuleTree(rulesByConditionVal.get(key)));
        }
        return subtree;
    }

    private Rule getHighestPriorityRule(List<Rule> rules) {
        Rule bestRule = null;
        int maxPriority = Integer.MIN_VALUE;
        for (Rule rule : rules) {
            if (maxPriority < rule.getPriority()) {
                maxPriority = rule.getPriority();
                bestRule = rule;
            }
        }
        return bestRule;
    }

    private Rule findRule(Map<String, String> reqMap) {
        if (conditionClause == null)
            return rule;
        else {
            String branch = reqMap.get(conditionClause);
            Rule r1 = subtree.get(branch) == null ? null : subtree.get(branch).findRule(reqMap);
            Rule r2 = subtree.get(null) == null ? null : subtree.get(null).findRule(reqMap);
            return r1 == null ? r2 : r2 == null ? r1 : r1.getPriority() < r2.getPriority() ? r2 : r1;
        }
    }

    public static synchronized void prepare(String partition, List<Rule> rules) {
        roots.put(partition, new RuleTree(rules));
    }

    public static Rule findBestRule(Request request) {
        return roots.get(request.getPartition()).findRule(request.flatMap());
    }

    public static RuleTree getRuleTree(String partition) {
        return roots.get(partition);
    }
}

package com.oracle.multitenent.ratecontrol.model;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

/**
 * This is a model to describe Rate Control Rate Grant Response
 */
@XmlRootElement
public class Grant implements Serializable {
    private static final long serialVersionUID = -436119276569069091L;

    // epoc time of last rule modified time, provided by RC Server, cannot be null
    private long rule_version;

    // list of all rules provided by RC Server when rule_version mismatch
    private List<Rule> rules;

    // token for delegated rate control
    private Token token;

    public Grant(long rule_version, List<Rule> rules, Token token) {
        this.rule_version = rule_version;
        this.rules = rules;
        this.token = token;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public long getRule_version() {
        return rule_version;
    }

    public Token getToken() {
        return token;
    }

    public static class Token {
        // Consistent hash of rate control rule so that server and client can communicate
        private String rate_key;

        // number of requests that is allowed until token has to be refreshed
        private int pass_allowed;

        // expiry time for pass allowed in the token
        private long pass_expiration = -1;

        // expiry time till which request should be blocked
        private long block_expiration = -1;

        // for creating allow grant token
        public Token(String rate_key, int pass_allowed, long pass_expiration) {
            this.rate_key = rate_key;
            this.pass_allowed = pass_allowed;
            this.pass_expiration = pass_expiration;
        }

        // for creating block grant token
        public Token(String rate_key, long block_expiration) {
            this.rate_key = rate_key;
            this.block_expiration = block_expiration;
        }

        public String getRate_key() {
            return rate_key;
        }

        public int getPass_allowed() {
            return pass_allowed;
        }

        public long getPass_expiration() {
            return pass_expiration;
        }

        public long getBlock_expiration() {
            return block_expiration;
        }
    }
}

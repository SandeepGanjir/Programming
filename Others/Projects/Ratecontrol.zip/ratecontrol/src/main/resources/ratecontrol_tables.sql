------------------------------------------------------ Partition ---------------------------------------------------------
create table if not exists centralcdb_rate_control_partition$ (
  name          varchar2(64) not null,
  key           varchar2(64) not null,
  primary key   ( name )
);

declare
  type  part is varray(2) of varchar2(64);
  type  all_part is varray(20) of part;
  parts all_part;
  total      integer;
begin
  parts := all_part( part('master', 'op0jzrpu8ywfriwqre3hitjyfzc711dr'), part('broker', 'uuc4vudjjl9pnuupd8owyi8xh7rubvnz'),
                  part('oml', '1zujvfk2dfce97670ol472khknm4cyyl'), part('graph', '2peiigzz17idmyu8solbwzxtgcpprbww') );
  total := parts.count;
  for i in 1..total loop
    begin
      insert into centralcdb_rate_control_partition$ ( name, key )
        values ( parts(i)(1), parts(i)(2) );
    exception
      when others then
      continue;
    end;
  end loop;
end;
/

------------------------------------------------------ Rules ---------------------------------------------------------
create table if not exists centralcdb_rate_control_rules$ (
  id            number generated always as identity (start with 1 increment by 1),
  partition     varchar2(64),
  name          varchar2(256),
  priority      number,
  test          number default 0,
  condition     clob constraint ensure_condition_is_json check (condition is json),
  dimension     clob constraint ensure_dimention_is_json check (dimention is json),
  rate          clob constraint ensure_rate_is_json check (rate is json),
  updated       timestamp,
  primary key   ( partition, name ),
  foreign key   ( partition ) references centralcdb_rate_control_partition$ ( name )
);
comment on column centralcdb_rate_control_rules$.id is 'generated unique identifier for each rate control rule';
comment on column centralcdb_rate_control_rules$.partition is 'application specific partition';
comment on column centralcdb_rate_control_rules$.name is 'identifier for rate control rule which may have many versions';
comment on column centralcdb_rate_control_rules$.priority is 'priority for each rate control rule to resolve conflict when several rules applicable';
comment on column centralcdb_rate_control_rules$.condition is 'rate control rule condition - set of patterns to match in conjunction for request';
comment on column centralcdb_rate_control_rules$.dimension is 'format to generate rate control key from request';
comment on column centralcdb_rate_control_rules$.rate is 'definition of rate';
comment on column centralcdb_rate_control_rules$.updated is 'timestamp for each rate control rule version to fins latest';

------------------------------------------------------ Satistics ---------------------------------------------------------
create table centralcdb_rate_control_statistics$ (
  id          number generated always as identity ( start with 1 increment by 1 ),
  partition   varchar2(64),
  rate_key    varchar(256) not null,
  client_id   varchar(50),
  allowed     number,
  blocked     number,
  ts          timestamp,
  foreign key ( partition ) references centralcdb_rate_control_partition$ ( name )
)
  partition by range ( ts ) interval ( interval '1' day )
    subpartition by hash ( rate_key ) subpartitions 512
  ( partition p_begin0_part
    values less than ( timestamp '2021-04-01 00:00:00' )
  );

create index centralcdb_rate_control_statistics_ts on centralcdb_rate_control_statistics$(ts) local;

comment on column centralcdb_rate_control_statistics$.id is 'unique identifier for each record';
comment on column centralcdb_rate_control_statistics$.partition is 'application specific partition';
comment on column centralcdb_rate_control_statistics$.rate_key is 'rate key corresponding to rule for which stat was collected';
comment on column centralcdb_rate_control_statistics$.client_id is 'unique client_id of the server which collected the statistic';
comment on column centralcdb_rate_control_statistics$.allowed is 'number of requests allowed by delegated server';
comment on column centralcdb_rate_control_statistics$.blocked is 'number of requests blocked by delegated server';
comment on column centralcdb_rate_control_statistics$.ts is 'timestamp of stats arrival on rc server';
------------------------------------------------------------------------------------------------------------------------
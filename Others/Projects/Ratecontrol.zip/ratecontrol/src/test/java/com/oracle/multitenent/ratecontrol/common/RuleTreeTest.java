package com.oracle.multitenent.ratecontrol.common;

import com.oracle.multitenent.ratecontrol.model.Request;
import com.oracle.multitenent.ratecontrol.model.Rule;
import com.oracle.multitenent.ratecontrol.util.JsonUtil;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class RuleTreeTest {
    private final Rule[] rules = {
            new Rule("Test", "ProvisioningDatabaseGet", 1000, false,
                    "{\"path_2\": \"databases\", \"method\": \"GET\"}", "{\"dimension\": \"p1\"}",
                    "{\"burst\": 5, \"periodMs\": 60000}", System.currentTimeMillis()),
            new Rule("Test", "ProvisioningDatabasePost", 1000, false,
                    "{\"path_2\": \"databases\", \"method\": \"POST\"}", "{\"dimension\": \"p1\"}",
                    "{\"burst\": 5, \"periodMs\": 60000}", System.currentTimeMillis()),
            new Rule("Test", "TenantsProvisioningPut", 1000, false,
                    "{\"path_0\": \"tenants\", \"method\": \"PUT\"}", "{\"dimension\": \"p1\"}",
                    "{\"burst\": 5, \"periodMs\": 60000}", System.currentTimeMillis()),
            new Rule("Test", "TenantsProvisioningRule", 1001, false,
                    "{\"path_0\": \"tenants\", \"method\": \"POST\"}", "{\"dimension\": \"p1\"}",
                    "{\"burst\": 5, \"periodMs\": 60000}", System.currentTimeMillis())
    };

    @Test
    public void testPrepareTree() {
        Request request = new Request("Test", "http://localhost:8080", "tenants/TENANT1/databases/",
                "87f69035-f4e4-4606-a2bb-464b06047859", null, "POST", "INTERNAL",
                JsonUtil.fromJson("{\"name\":[\"TENANT1\"],\"database\":[\"SANDEEP01\",\"VASSILI\"]}", Map.class),
                JsonUtil.fromJson("{\"mode\":[\"hard\"]}", Map.class));
        RuleTree.prepare(request.getPartition(), Arrays.asList(rules));
        assertEquals("TenantsProvisioningRule", RuleTree.findBestRule(request).getName());
    }
}

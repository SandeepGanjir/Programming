package com.oracle.multitenent.ratecontrol.util;

import com.oracle.multitenent.ratecontrol.model.Rule;
import org.junit.Test;

import java.sql.Timestamp;

import static org.junit.Assert.assertEquals;

public class JsonUtilTest {
    @Test
    public void testSerialization() {
        String refStr = "{\"partition\":\"Test\",\"name\":\"TenantsProvisioningRule\",\"priority\":20000,\"isTestRun\":false," +
                "\"condition\":{\"path_0\":\"tenants\",\"method\":\"POST\"},\"dimension\":{\"dimension\":\"p1\"}," +
                "\"rate\":{\"burst\":5,\"periodMs\":60000},\"updated\":1615993491643}";
        Rule rule = new Rule("Test","TenantsProvisioningRule", 20000,
                false, "{\"path_0\": \"tenants\", \"method\": \"POST\"}",
                "{\"dimension\": \"p1\"}", "{\"burst\": 5, \"periodMs\": 60000}", 1615993491643L);
        assertEquals(refStr, JsonUtil.toJson(rule));
    }

    @Test
    public void testDeserialization() {
        String refStr = "{\"partition\":\"Test\",\"name\":\"TenantsProvisioningRule\",\"priority\":20000,\"isTestRun\":false," +
                "\"condition\":{\"path_0\":\"tenants\",\"method\":\"POST\"},\"dimension\":{\"dimension\":\"p1\"}," +
                "\"rate\":{\"burst\":5,\"periodMs\":60000},\"updated\":1615993491643}";
        Rule rule = JsonUtil.fromJson(refStr, Rule.class);
        assertEquals(refStr, JsonUtil.toJson(rule));
    }
}

package com.oracle.multitenent.ratecontrol.util;

import com.oracle.multitenent.ratecontrol.model.Rule;
import com.typesafe.config.ConfigFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class DbUtilTest {
    private final Rule rule = new Rule("Test", "TestRule", 12345, false,
            "{\"path_0\": \"tenants\", \"method\": \"POST\"}", "{\"dimension\": \"p1\"}",
            "{\"burst\": 5, \"periodMs\": 60000}", System.currentTimeMillis());

    @Before
    public void setup() {
        DbUtil.init(ConfigFactory.parseResources("default.conf").getConfig("db"));
    }

    @Test
    public void testGetPartitions() {
        assertEquals(4, DbUtil.getPartitions().size());
    }

    @Test
    public void testAddRule() {
        assertTrue(DbUtil.addRule(rule.getPartition(), rule));
        DbUtil.deleteRule(rule.getPartition(), rule.getName());
    }

    @Test
    public void testGetRules() {
        DbUtil.addRule(rule.getPartition(), rule);
        List<Rule> rules = DbUtil.getRules(rule.getPartition(), rule.getName());
        assertEquals(rule.getName(), rules.get(0).getName());
        DbUtil.deleteRule(rule.getPartition(), rule.getName());
    }

    @Test
    public void testDeleteRule() {
        DbUtil.addRule(rule.getPartition(), rule);
        assertTrue(DbUtil.deleteRule(rule.getPartition(), rule.getName()));
    }
    @Test
    public void testAddStatistics() {
        // ToDo:
    }

    @Test
    public void testGetStatistics() {
        // ToDo:
    }

    @After
    public void tearDown() {
        DbUtil.deleteRule(rule.getPartition(), rule.getName());
    }
}

package com.oracle.multitenent.ratecontrol.server;

public class DistributedRateManagementTest {
    // ToDo:
}

package com.oracle.multitenent.ratecontrol.server;

import com.oracle.multitenent.ratecontrol.model.Rule;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RateManagementTest {
    @Test
    public void testRateManagement() {
        Rule rule = new Rule("Test", "TenantsProvisioningRule", 1001, false,
                "{\"path_0\": \"tenants\", \"method\": \"POST\"}", "{\"dimension\": \"p1\"}",
                "{\"burst\": 3, \"periodMs\": 60000}", System.currentTimeMillis());

        assertTrue(RateManagement.allowRequest(rule));
        assertTrue(RateManagement.allowRequest(rule));
        assertTrue(RateManagement.allowRequest(rule));
        assertFalse(RateManagement.allowRequest(rule));
        assertFalse(RateManagement.allowRequest(rule));
        RateManagement.reset(rule.getPartition());
        assertTrue(RateManagement.allowRequest(rule));
    }
}

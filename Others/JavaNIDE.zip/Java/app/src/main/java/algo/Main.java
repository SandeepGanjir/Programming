package algo;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;


public class Main {

  public static void main(String[] args) throws Exception {
    //ArrayOptimizeDP.main(args);
    //BestRoute.main(args);
    //Candy.main(args);
    //CargoShip.main(args);
    //DisjointSet.main(args);
    //EqualOccurence.main(args);
    //KadaneAlgo.main(args);
    //LargestBST.main(args);
    //LargestMonotonicSubsequence.main(args);
    //LongestBalancedParenthesis.main(args);
    //MooreVotingAlgo.main(args);
    //Palindrome.main(args);
    //PrefixToPostfix.main(args);
    //RebuildQueue.main(args);
    //RightPosition.main(args);
    //TreeNode.main(args);
    //frogRoutes.main(args);
    
    List<String> classes = new ArrayList<>();
    classes.add("ArrayOptimizeDP");
    classes.add("BestRoute");
    classes.add("Candy");
    classes.add("CargoShip");
    classes.add("DisjointSet");
    classes.add("EqualOccurence");
    classes.add("KadaneAlgo");
    classes.add("LargestBST");
    classes.add("LargestMonotonicSubsequence");
    classes.add("LongestBalancedParenthesis");
    classes.add("MooreVotingAlgo");
    classes.add("Palindrome");
    classes.add("PrefixToPostfix");
    classes.add("RebuildQueue");
    classes.add("RightPosition");
    classes.add("TreeNode");
    classes.add("frogRoutes");
    
    for (String clazz : classes) {
      Class<?> claz = Class.forName("algo." + clazz);
      Method method = claz.getMethod("main", args.getClass());
      
      System.out.println("\n\nRunning main from class - " + clazz);
      method.invoke(null, new Object[] {args});
    }
  }
}
